> PROYECTO DE ANALITICA DE DATOS **Identificación** **y**
> **planteamiento** **del** **problema**
>
> La deserción escolar en Colombia representa una profunda brecha a
> nivel educativo y social, que a lo largo de los estudios realizados se
> ha asociado directamente a temas socioeconómicos y de infraestructura,
> dejando de lado las condiciones de salud, las cuales afecta de manera
> directa el factor educativo.
>
> De acuerdo a los datos del Ministerio de Educación Nacional “En todo
> el mundo, los sistemas educativos enfrentan el desafío constante de
> mantener a los estudiantes en las aulas, una tarea que se vuelve
> titánica cuando las crisis sanitarias y las condiciones de salud
> endémicas de los territorios impactan a la población más joven. En
> Colombia, a pesar de los esfuerzos gubernamentales por ampliar la
> cobertura, persisten altas tasas de abandono escolar, un fenómeno
> multifactorial que evidencia la necesidad de fortalecer las políticas
> de permanencia (*Ministerio* *de* *Educación* *Nacional*, 2022). A
> nivel local y regional, las grandes diferencias en la atención médica
> y la exposición a enfermedades agudas o crónicas determinan en gran
> medida la capacidad de un menor para asistir regularmente a clases, lo
> que a menudo termina en la desvinculación definitiva del sistema,
> viéndose especialmente afectada la transición hacia la educación media
> (Observatorio de Realidades Educativas, 2025).”
>
> "En Colombia, como lo señala el (*Ministerio* *de* *Educación*
> *Nacional*, 2022), a pesar de los esfuerzos gubernamentales por
> ampliar la cobertura, persisten altas tasas de abandono escolar,
> especialmente en la transición de primaria a secundaria. Además,
> reportes recientes del **Observatorio** **de** **Realidades**
> **Educativas** **(2025)** evidencian que la pérdida de estudiantes al
> llegar a la educación media sigue siendo crítica.
>
> El problema central radica en la brecha de integración analítica entre
> el sector educativo y factores de incidencia como condiciones de
> salud, condiciones socioeconómicas y condiciones demográficas.
> Actualmente, los datos del Sistema de Vigilancia en Salud Pública,
> estadísticas de matrícula del Ministerio de Educación y DANE se
> analizan en silos independientes. Esta falta de correlación impide
> identificar de manera proactiva cómo, cuándo y cuáles factores
> específicos actúan como catalizadores directos del abandono escolar,
> limitando la capacidad del Estado para generar alertas tempranas
> conjuntas.
>
> Esta desconexión es grave porque perpetúa un ciclo de vulnerabilidad:
> un niño que abandonala escuelapor cualquieradeestos factores no solo
> pierdesu derecho ala educación, sino que disminuye drásticamente sus
> oportunidades futuras de movilidad social. Esta situación afecta
> directamente a niños y adolescentes en etapas críticas de desarrollo
> (básica y media), impactando a largo plazo el capital humano y el
> desarrollo económico del país.
>
> **Formulación** **o** **Pregunta** **de** **Investigación**
>
> ¿De qué manera factores como la incidencia de enfermedades reportadas
> en el sistema de vigilancia de salud pública, condiciones
> socioeconómicas y condiciones demográficas influyó en las tasas de
> deserción escolar en los niveles de educación básica y media en
> Colombia durante el periodo 2011-2022?
>
> **Objetivos**
>
> ***Objetivo*** ***general***
>
> Desarrollar un modelo predictivo basado en técnicas de aprendizaje
> automático que permita correlacionar y estimar el riesgo de deserción
> escolar en la educación básica y media en Colombia entre 2011 y 2022,
> integrando indicadores de salud pública provenientes del Sistema de
> Vigilancia en Salud Pública (SIVIGILA), junto con la variable
> demográfica (edad) y socioeconómicas (nivel de ingresos) provenientes
> de Terridata.
>
> ***Objetivos*** ***específicos***
>
> • Preprocesar los conjuntos de datos de Terridata y el portal de Datos
> de
>
> Vigilancia en Salud Pública, consolidando una base de datos unificada
> a nivel departamental y municipal para el periodo de estudio.
>
> • Identificar las variables epidemiológicas con mayor correlación
> estadística respecto alos picos históricos dedeserción escolaren la
> transición dela educación primaria a la secundaria.
>
> • Entrenar diferentes algoritmos de predicción (como Regresión
> Logística, Random Forest o XGBoost) para pronosticar el comportamiento
> de la deserción escolar basándose en el panorama de salud pública de
> una región específica.
>
> • Examinar la influencia de factores demográficos, especialmente en
> niños y adolescentes hasta los 14 años y evaluando variable
> socioeconómica como pobreza en la probabilidad de deserción escolar.
>
> • **DATASET** **MEN_ESTADISTICAS_EN_EDUCACION_EN_PREESCOLAR,**
> **BÁSICA** **Y** **MEDIA_POR_MUNICIPIO**
>
> Contiene información estadística de los niveles preescolar, básica y
> media relacionada con
>
> indicadores sectoriales por Municipio sin atípicos, desde el 2011
> hasta 2024.
>
> NOTA: Para las tasas de cobertura bruta y neta 2019 y 2018 se
> realizaron con las proyecciones de población Censo 2018.
>
> Cabe mencionar que los datos de cada indicador esta con punto decimal,
> al momento de exportar los datos se multiplica por 100, para
> convertirlo a porcentajes. Este dataset tiene 41 columnas. Adjuntola
> descripción de cada uno de ellos.

<img src="./xm51mvcv.png"
style="width:5.47639in;height:4.41625in" /><img src="./pwsrr40n.png"
style="width:5.24986in;height:3.97986in" />

<img src="./vwtchiwd.png"
style="width:4.86528in;height:4.41667in" /><img src="./hp5icexh.png"
style="width:4.865in;height:4.05139in" />

<img src="./ml14vkh4.png"
style="width:4.20347in;height:3.33306in" /><img src="./d5hqu3ei.png" style="width:4.25in;height:3.8225in" />

<img src="./3jwttuto.png"
style="width:6.1375in;height:5.41736in" /><img src="./cu15cant.png"
style="width:6.1375in;height:0.97153in" />

<img src="./z3r4xxte.png"
style="width:6.1375in;height:4.49583in" />

> **DATASET** **Datos** **de** **Vigilancia** **en** **Salud**
> **Pública** **de** **Colombia**
>
> El Sistema Nacional de Vigilancia en Salud Pública -SIVIGILA, que se
> ha creado para realizar la provisión en forma sistemática y oportuna,
> de información sobre la dinámica de los eventos que afecten o puedan
> afectar la salud de la población colombiana, con el fin de (i)
> Orientar las políticas y la planificación en salud pública, (ii) Tomar
> las decisiones para la prevención y control de enfermedades y factores
> de riesgo en salud, (iii) Optimizar el seguimiento y evaluación de las
> intervenciones, (iv) Racionalizar y optimizar los recursos disponibles
> y lograr la efectividad de las acciones en esta materia, propendiendo
> por la protección de la salud individual y colectiva. Este conjunto de
> datos compila el historico de casos de eventos de interes en salud
> publica por municipio-departamento de ocurrencia y por semana
> epidemiológica y año desde 2007.
>
> DATASET TERRIDATA DIMENSION DE POBREZA
>
> Contiene 13 columnas con 21689 filas.

<img src="./1ekfycgj.png"
style="width:6.62708in;height:3.93736in" /><img src="./iy3n5vck.png"
style="width:6.1375in;height:2.76111in" />

> DATASET DE CONVIVENCIAY SEGURIDAD CIUDADANA
>
> Datos de la variable indicador

<img src="./4lhguskc.png"
style="width:6.1375in;height:6.68542in" />

<img src="./jkiofzny.png"
style="width:6.1375in;height:4.87222in" />

> <img src="./umvjgbhs.png"
> style="width:6.1375in;height:3.29861in" />DATASET
> VIOLENCIA_INTRAFAMILIAR.\_COLOMBIA, \_AÑOS_2015_A_2024

<img src="./rgvyr4ql.png"
style="width:6.1375in;height:3.29861in" /><img src="./s1mf33yd.png"
style="width:6.1375in;height:3.29861in" />

<img src="./ji0y3zgn.png"
style="width:6.1375in;height:3.29861in" /><img src="./pq0atl5s.png"
style="width:3.72986in;height:5.13528in" />
